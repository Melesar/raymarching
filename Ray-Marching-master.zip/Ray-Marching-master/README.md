# Ray Marching
Experimenting with using ray marching to render signed distance functions in Unity.
This is just a test project, so beware! It is very unoptimized and incomplete.
See my video on this project here: https://www.youtube.com/watch?v=Cp5WWtMoeKg

To run this project you'll need to open it in the Unity game engine: https://unity3d.com/

Rendering of mandelbulb fractal:
![Mandelbulb](https://i.imgur.com/D0Dhn0a.png)
Simple scene showing cutting and blending operations:
![Scene](https://i.imgur.com/DJRz688.png)
